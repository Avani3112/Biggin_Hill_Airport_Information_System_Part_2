-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: life_insurance_co_li_boyd
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `Employee_Number` int NOT NULL,
  `Employee_Title` varchar(50) DEFAULT NULL,
  `Employee_First` varchar(255) DEFAULT NULL,
  `Employee_Last` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Phone` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Department_Code` int DEFAULT NULL,
  PRIMARY KEY (`Employee_Number`),
  KEY `Department_Code` (`Department_Code`),
  CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`Department_Code`) REFERENCES `department` (`Department_Code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1001,'Manager','John','Doe','john.doe@example.com','5551112233','123 Main St, City',101),(1002,'Analyst','Jane','Smith','jane.smith@example.com','5552223344','456 Elm St, Town',102),(1003,'HR Specialist','Michael','Johnson','michael.johnson@example.com','5553334455','789 Oak St, Village',103),(1004,'Claims Adjuster','Emily','Brown','emily.brown@example.com','5554445566','321 Pine St, Hamlet',104),(1005,'Customer Service Representative','David','Wilson','david.wilson@example.com','5555556677','654 Cedar St, Suburb',105),(1006,'Policy Administrator','Sarah','Martinez','sarah.martinez@example.com','5556667788','987 Maple St, County',106),(1007,'Risk Analyst','Chris','Taylor','chris.taylor@example.com','5557778899','159 Birch St, Borough',107),(1008,'Accountant','Amanda','Garcia','amanda.garcia@example.com','5558889900','753 Walnut St, District',108),(1009,'Product Developer','Kevin','Rodriguez','kevin.rodriguez@example.com','5559990011','357 Spruce St, Township',109),(1010,'IT Specialist','Laura','Lopez','laura.lopez@example.com','5550001122','852 Ash St, Municipality',110);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-28 19:59:15
