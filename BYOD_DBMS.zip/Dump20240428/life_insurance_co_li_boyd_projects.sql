-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: life_insurance_co_li_boyd
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `Project_Team_ID` int NOT NULL,
  `Project_Name` varchar(255) DEFAULT NULL,
  `Project_Description` varchar(255) DEFAULT NULL,
  `Project_Start_Date` date DEFAULT NULL,
  `Project_End_Date` date DEFAULT NULL,
  `Business_Issue` varchar(255) DEFAULT NULL,
  `Employee_Number` int DEFAULT NULL,
  PRIMARY KEY (`Project_Team_ID`),
  KEY `Employee_Number` (`Employee_Number`),
  CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`Employee_Number`) REFERENCES `employees` (`Employee_Number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (2001,'Marketing Campaign Launch','Launching a new marketing campaign','2024-05-01','2024-06-30','Increase brand awareness',1001),(2002,'Compliance Audit Preparation','Preparing for compliance audits','2024-05-05','2024-05-31','Ensure regulatory compliance',1002),(2003,'HR Training Program Development','Developing a training program','2024-05-10','2024-07-15','Employee skill enhancement',1003),(2004,'Claims Processing Automation','Automating claims processing','2024-05-15','2024-08-31','Streamline claims handling',1004),(2005,'Customer Feedback Analysis','Analyzing customer feedback','2024-05-20','2024-06-30','Improve customer satisfaction',1005);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-28 19:59:16
