-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: life_insurance_co_li_boyd
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `device_information`
--

DROP TABLE IF EXISTS `device_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_information` (
  `Device_ID` int NOT NULL,
  `Brand_Name` varchar(255) DEFAULT NULL,
  `Model_Number` int DEFAULT NULL,
  `Device_Value` decimal(10,2) DEFAULT NULL,
  `Operating_System` varchar(50) DEFAULT NULL,
  `Device_Version` varchar(50) DEFAULT NULL,
  `MAC_Address` varchar(255) DEFAULT NULL,
  `SID` varchar(50) DEFAULT NULL,
  `Apple_ID` varchar(50) DEFAULT NULL,
  `Screen_Lock_Enabled` varchar(50) DEFAULT NULL,
  `Bitlocker_Encryption_Enabled` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Device_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_information`
--

LOCK TABLES `device_information` WRITE;
/*!40000 ALTER TABLE `device_information` DISABLE KEYS */;
INSERT INTO `device_information` VALUES (3001,'Dell',123456,899.99,'Windows','10','00-1A-2B-3C-4D-5E',NULL,NULL,'Enabled','Enabled'),(3002,'HP',789012,1099.99,'Windows','11','00-2B-3C-4D-5E-6F',NULL,NULL,'Enabled','Enabled'),(3003,'Lenovo',345678,799.99,'Windows','10','00-3C-4D-5E-6F-7G',NULL,NULL,'Enabled','Enabled'),(3004,'Apple',NULL,1299.99,'iOS','15.3',NULL,'A1234567','apple@example.com','Enabled','Enabled'),(3005,'Samsung',NULL,899.99,'Android','12',NULL,'S9876543',NULL,'Enabled','Enabled'),(3006,'Microsoft',567890,799.99,'Windows','10','00-4D-5E-6F-7G-8H',NULL,NULL,'Enabled','Enabled'),(3007,'Apple',NULL,1499.99,'iOS','15.3',NULL,'A7654321','iphone@example.com','Enabled','Enabled'),(3008,'Samsung',NULL,1099.99,'Android','12',NULL,'S5432167',NULL,'Enabled','Enabled'),(3009,'Microsoft',678901,999.99,'Windows','11','00-5E-6F-7G-8H-9I',NULL,NULL,'Enabled','Enabled'),(3010,'Apple',NULL,1799.99,'iOS','15.3',NULL,'A2468101','ipad@example.com','Enabled','Enabled');
/*!40000 ALTER TABLE `device_information` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-28 19:59:15
