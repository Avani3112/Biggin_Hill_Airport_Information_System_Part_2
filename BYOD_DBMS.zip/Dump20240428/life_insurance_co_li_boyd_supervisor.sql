-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: life_insurance_co_li_boyd
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `supervisor`
--

DROP TABLE IF EXISTS `supervisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supervisor` (
  `Supervisor_ID` int NOT NULL,
  `Policy_Number` int DEFAULT NULL,
  `Group_Policy` varchar(255) DEFAULT NULL,
  `Approval_Date` date DEFAULT NULL,
  `Department_Code` int DEFAULT NULL,
  `Identification_Number` int DEFAULT NULL,
  PRIMARY KEY (`Supervisor_ID`),
  KEY `Identification_Number` (`Identification_Number`),
  KEY `Department_Code` (`Department_Code`),
  CONSTRAINT `supervisor_ibfk_1` FOREIGN KEY (`Identification_Number`) REFERENCES `device_registration` (`Identification_Number`),
  CONSTRAINT `supervisor_ibfk_2` FOREIGN KEY (`Department_Code`) REFERENCES `department` (`Department_Code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supervisor`
--

LOCK TABLES `supervisor` WRITE;
/*!40000 ALTER TABLE `supervisor` DISABLE KEYS */;
INSERT INTO `supervisor` VALUES (5001,10001,'SalesGroupPolicy','2024-04-10',101,4001),(5002,10002,'ComplianceGroupPolicy','2024-04-11',102,4002),(5003,10003,'HRGroupPolicy','2024-04-12',103,4003),(5004,10004,'ClaimsGroupPolicy','2024-04-13',104,4004),(5005,10005,'CustomerServiceGroupPolicy','2024-04-14',105,4005),(5006,10006,'PolicyAdministrationGroupPolicy','2024-04-15',106,4006),(5007,10007,'RiskManagementGroupPolicy','2024-04-16',107,4007),(5008,10008,'AccountingGroupPolicy','2024-04-17',108,4008),(5009,10009,'ProductDevelopmentGroupPolicy','2024-04-18',109,4009),(5010,10010,'ITGroupPolicy','2024-04-19',110,4010);
/*!40000 ALTER TABLE `supervisor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-28 19:59:16
